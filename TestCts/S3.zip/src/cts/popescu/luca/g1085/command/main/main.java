package cts.popescu.luca.g1085.command.main;

import cts.popescu.luca.g1085.command.clase.RobotSoftware;

public class main {
    public static void main(String[] args) {
       // RobotSoftware robotSoftware=new RobotSoftware(NORMALA);
    }
}
