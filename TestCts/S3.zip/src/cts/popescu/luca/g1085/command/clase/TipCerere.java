package cts.popescu.luca.g1085.command.clase;

public enum TipCerere {
    NORMALA, URGENTA;
}