package cts.popescu.luca.g1085.command.clase;

public interface IProcesatorCerere {
    public void procesareCerere(TipCerere tip, String denumire);
}