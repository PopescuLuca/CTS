package cts.popescu.luca.g1085.command.clase;

public class EliberareDiploma implements IProcesatorCerere {
    @Override
    public void procesareCerere(TipCerere tip, String denumire) {

    }
}
