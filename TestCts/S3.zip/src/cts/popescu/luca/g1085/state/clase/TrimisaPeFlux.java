package cts.popescu.luca.g1085.state.clase;

public class TrimisaPeFlux implements StareCerere {
    @Override
    public void modificaStare(Cerere cerere) {

    }
}
