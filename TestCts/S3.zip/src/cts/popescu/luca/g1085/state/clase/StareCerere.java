package cts.popescu.luca.g1085.state.clase;

public interface StareCerere {
    public void modificaStare(Cerere cerere);
}
