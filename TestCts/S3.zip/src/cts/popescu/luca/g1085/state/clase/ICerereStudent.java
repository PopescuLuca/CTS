package cts.popescu.luca.g1085.state.clase;

public interface ICerereStudent {
    public void confirmare();

    public void verificare();

    public void avizareDecanat();

    public void respingere();
}